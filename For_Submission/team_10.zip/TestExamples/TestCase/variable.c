int main() {
    float a;
    int b;
    char c;
    bool d;
    return 0;
}