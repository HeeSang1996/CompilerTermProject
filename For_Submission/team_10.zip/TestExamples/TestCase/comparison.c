void main() {
    int a = 0;
    int b = 5;
    bool c;

    c = i<j;
    c = i <j;
    c = i< j;
    c = i < j;
    c =i<j;
    c =i <j;
    c =i< j;
    c =i < j;
    c=i<j;
    c=i <j;
    c=i< j;
    c=i < j;

    c = i>j;
    c = i >j;
    c = i> j;
    c = i > j;
    c =i>j;
    c =i >j;
    c =i> j;
    c =i > j;
    c=i>j;
    c=i >j;
    c=i> j;
    c=i > j;

    c = i==j;
    c = i ==j;
    c = i== j;
    c = i == j;
    c =i==j;
    c =i ==j;
    c =i== j;
    c =i == j;
    c=i==j;
    c=i ==j;
    c=i== j;
    c=i == j;

    c = i!=j;
    c = i !=j;
    c = i!= j;
    c = i != j;
    c =i!=j;
    c =i !=j;
    c =i!= j;
    c =i != j;
    c=i!=j;
    c=i !=j;
    c=i!= j;
    c=i != j;
    
    c = i<=j;
    c = i <=j;
    c = i<= j;
    c = i <= j;
    c =i<=j;
    c =i <=j;
    c =i<= j;
    c =i <= j;
    c=i<=j;
    c=i <=j;
    c=i<= j;
    c=i <= j;

    c = i>=j;
    c = i >=j;
    c = i>= j;
    c = i >= j;
    c =i>=j;
    c =i >=j;
    c =i>= j;
    c =i >= j;
    c=i>=j;
    c=i >=j;
    c=i>= j;
    c=i >= j;
}