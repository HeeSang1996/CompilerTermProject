void main() {
    int a,b;
    float c, d;
    bool e , f;
    char g,h,i,j,k;
    char l, m, n, o, p;
    char q , r , s , t , u;
}