int main() {
    bool a = true;
    bool a =true;
    bool c = false;
    bool d =false;

    return 0;
}