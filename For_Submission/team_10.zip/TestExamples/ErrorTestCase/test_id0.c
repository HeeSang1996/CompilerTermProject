int main() {
    int a.a = 0;
    return 0;
}