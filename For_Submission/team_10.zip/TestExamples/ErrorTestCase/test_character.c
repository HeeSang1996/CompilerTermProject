int main() {
    char s = "i like money $$";
    printf(s);
    return 0;
}