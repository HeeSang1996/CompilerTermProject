lexical_analyzer.exe can be excuted by windows cmd.
put your <input_file_name> file in the same directory with lexical_analyzer.exe,
and please type on cmd window.

lexical_analyzer <input_file_name>

e.g) 
cmd
C:\Users\admin\Desktop\test>lexical_analyzer arithmatic1.c
...
...
then, you can find .out file that includes the result of our program in the same directory.
 