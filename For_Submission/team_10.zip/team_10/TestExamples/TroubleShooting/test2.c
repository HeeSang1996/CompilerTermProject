int main() {
    float a = .3;
    return 0;
}