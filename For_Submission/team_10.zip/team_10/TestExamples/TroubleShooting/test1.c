int main() {
    int int_ABC = 3;
    int intABC = 4;
    float ifABC = 3.3;
    bool while_abc = true;
    char while3ABC = "HI";
    return 0;
}