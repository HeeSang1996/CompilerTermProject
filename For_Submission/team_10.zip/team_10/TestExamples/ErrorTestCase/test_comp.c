int main() {
    int a = 3;
    int b = 5;
    if (a=!b){
        print("a and b are different integer")
    }
    return 0;
}