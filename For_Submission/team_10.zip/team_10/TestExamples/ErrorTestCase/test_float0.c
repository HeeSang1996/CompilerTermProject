int main() {
    int b = 3;
    float a = .0;
    return 0;
}