void main() {
    int a = 8;
    int b = 0;

    int c = a<<2;
    int d = a <<2;
    int e = a<< 2;
    int f = a << 2;
    int g =a<<2;
    int h =a <<2;
    int i =a<< 2;
    int j =a << 2;
    int k=a<<2;
    int l=a <<2;
    int m=a<< 2;
    int n=a << 2;

    int o = a>>2;
    int p = a >>2;
    int q = a>> 2;
    int r = a >> 2;
    int s =a>>2;
    int t =a >>2;
    int u =a>> 2;
    int v =a >> 2;
    int w=a>>2;
    int x=a >>2;
    int y=a>> 2;
    int z=a >> 2;

    int aa = a&b;
    int ab = a& b;
    int ac = a &b;
    int ad = a & b;
    int ae =a&b;
    int af =a& b;
    int ag =a &b;
    int ah =a & b;
    int ai=a&b;
    int aj=a &b;
    int ak=a& b;
    int al=a & b;

    int am = a|b;
    int an = a| b;
    int ao = a |b;
    int ap = a | b;
    int aq =a|b;
    int as =a| b;
    int at =a |b;
    int au =a | b;
    int av=a|b;
    int aw=a |b;
    int ax=a| b;
    int ay=a | b;

    int az = a&b|a<<b
}