int main() {
    while(true){}
    while(true) {}
    while (true){}
    while (true) {}

    return 0;
}