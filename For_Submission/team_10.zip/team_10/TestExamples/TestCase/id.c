void main() {
    char abc;
    char abc_;
    char abc_else;
    char abc_123;
    char abc_abc;
    char abc_1a2b;
    char a1b2c3;
    char a1b2c3_;
    char a1b2c3_else;
    char a1b2c3_abc;
    char a1b2c3_123;
    char a1b2c3_1a2b;
    char _abc;
    char _abc_;
    char _abc_123;
    char _abc_abc;
    char _abc_1a2b;
    char _a1b2c3;
    char _a1b2c3_;
    char _a1b2c3_abc;
    char _a1b2c3_123;
    char _a1b2c3_1a2b;
    
    int if_;
    int if_else;
    int if_123;
    int if_abc;
    int if_1a2b;
    int _if_;
    int _if_else;
    int _if_123;
    int _if_abc;
    int _if_1a2b;

    float _123;
    float _123_;
    float _123_abc;
    float _123_123;
    float _123_1a2b;
    float _123_else;
}