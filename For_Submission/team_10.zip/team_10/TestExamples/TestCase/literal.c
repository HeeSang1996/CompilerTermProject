void main() {
    char a = "123";
    char b = "abc";
    char c = " ";
    char d = "Hello World 123";
}