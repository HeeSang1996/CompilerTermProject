void main() {
    float a = 0.0;
    float b = 0.0123456789;
    float c = 0.0000000001;
    float d = 1.0;
    float e = 1234567890.0;
    float f = 1.0123456789;
    float g = 1.0000000001;

    float h =0.0;
    float i =0.0123456789;
    float j =0.0000000001;
    float k =1.0;
    float l =1234567890.0;
    float m =1.0123456789;
    float n =1.0000000001;

    float o=0.0;
    float p=0.0123456789;
    float q=0.0000000001;
    float r=1.0;
    float s=1234567890.0;
    float t=1.0123456789;
    float u=1.0000000001;
}