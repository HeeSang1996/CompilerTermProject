void main() {
    int a = 5;
    int b = 3;
    int c;

    c = a*b;
    c = a *b;
    c = a* b;
    c = a * b;
    c =a*b;
    c =a *b;
    c =a* b;
    c =a * b;
    c=a*b;
    c=a *b;
    c=a* b;
    c=a * b;

    c = a/b;
    c = a /b;
    c = a/ b;
    c = a / b;
    c =a/b;
    c =a /b;
    c =a/ b;
    c =a / b;
    c=a/b;
    c=a /b;
    c=a/ b;
    c=a / b;

    c = a+b;
    c = a +b;
    c = a+ b;
    c = a + b;
    c =a+b;
    c =a +b;
    c =a+ b;
    c =a + b;
    c=a+b;
    c=a +b;
    c=a+ b;
    c=a + b;

    c = a-b;
    c = a -b;
    c = a- b;
    c = a - b;
    c =a-b;
    c =a -b;
    c =a- b;
    c =a - b;
    c=a-b;
    c=a -b;
    c=a- b;
    c=a - b;
}